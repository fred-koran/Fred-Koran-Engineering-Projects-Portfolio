# Frederic Koran — Engineering Portfolio

Two self-contained HTML documents. No build step, no dependencies, no internet
connection required once loaded — fonts and figures are embedded in the files.

| File | Contents |
| --- | --- |
| `index.html` | Engineering Projects — 16 projects, 53 pages, with contents and page numbers |
| `resume.html` | One-page resume, linking through to the portfolio |

Both print to PDF from any browser at US Letter, one sheet per page.
